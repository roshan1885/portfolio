<?php

namespace Pterodactyl\Contracts\Repository;

interface PermissionRepositoryInterface extends RepositoryInterface
{
}
